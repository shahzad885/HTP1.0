import 'package:flutter/material.dart';

const kPinkLightColor =  TextStyle(
  // color: Color(0xffB71540),
color: Colors.black,
);

// var kTextStyleNormal =  GoogleFonts.montserrat(

//                         // color: Colors.white,
//                        //fontSize: screenWidth * 0.045,
//                       );